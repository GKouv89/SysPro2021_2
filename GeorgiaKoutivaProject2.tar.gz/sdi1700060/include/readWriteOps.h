#ifndef READWRITEOPS_H
#define READWRITEOPS_H

void read_content(char **, char **, int, int);
void write_content(char *, char **, int, int);

#endif