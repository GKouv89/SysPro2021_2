#ifndef DATEOPS_H
#define DATEOPS_H

void dateValidity(char *, char *);
int dateFormatValidity(char *);
int dateComparison(char *, char *);
int dateDiff(char *, char *);
#endif