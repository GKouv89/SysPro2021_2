#ifndef INPUTPARSING_H
#define INPUTPARSING_H

#include "hashmap.h"

void inputFileParsing(hashMap *, hashMap *, hashMap *, FILE *, int);

#endif